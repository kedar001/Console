﻿using Syncfusion.DocIO;
using Syncfusion.DocIO.DLS;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DDLLCS;
using System.Data;
using eDocsDN_Get_Directory_Info;


namespace eDocDN_Add_Signatory_Page
{
    public class ClseAdd_Signatory_Page : IDisposable
    {
        #region .... Variable Declaration .....
        string _szAppXmlPath = string.Empty;
        string _szDBName = string.Empty;
        string _szFilePath = string.Empty;
        string _szSqlQuery = string.Empty;
        string _szDateFormat = string.Empty;
        ClsBuildQuery _objDal = null;
        public Stream _strmDocument;
        //string _szLogFileName = AppDomain.CurrentDomain.BaseDirectory + @"\Log\AddSignatory.txt";

        #endregion
        public string msgError { get; set; }
        public Documents_Process eDocumentProcess { get; set; }

        public ClseAdd_Signatory_Page(string szAppXmlPath, string szFileName)
        {
            msgError = string.Empty;
            _szAppXmlPath = szAppXmlPath;
            _szFilePath = szFileName;
            Syncfusion.Licensing.SyncfusionLicenseProvider.RegisterLicense("NRAiBiAaIQQuGjN/V0Z+XU9EaFtFVmJLYVB3WmpQdldgdVRMZVVbQX9PIiBoS35RdEVlWXZecHRcRmRdVkJ3");
        }
        public ClseAdd_Signatory_Page(ClsBuildQuery objDal, string szFileName)
        {
            msgError = string.Empty;
            _objDal = objDal;
            _szFilePath = szFileName;
            Syncfusion.Licensing.SyncfusionLicenseProvider.RegisterLicense("NRAiBiAaIQQuGjN/V0Z+XU9EaFtFVmJLYVB3WmpQdldgdVRMZVVbQX9PIiBoS35RdEVlWXZecHRcRmRdVkJ3");
        }
        public ClseAdd_Signatory_Page(ClsBuildQuery objDal, Stream strmDocument)
        {
            msgError = string.Empty;
            _objDal = objDal;
            _strmDocument = strmDocument;
            Syncfusion.Licensing.SyncfusionLicenseProvider.RegisterLicense("NRAiBiAaIQQuGjN/V0Z+XU9EaFtFVmJLYVB3WmpQdldgdVRMZVVbQX9PIiBoS35RdEVlWXZecHRcRmRdVkJ3");
        }

        public ClseAdd_Signatory_Page(string szDBName, string szAppXmlPath, Stream strmDocument)
        {
            msgError = "";
            _szAppXmlPath = szAppXmlPath;
            _szDBName = szDBName;
            _objDal = new ClsBuildQuery(_szDBName, _szAppXmlPath);
            _objDal.OpenConnection(ConnectionFor.DocsExecutive, ConnectionType.NewConnection);
            _szFilePath = null;
            _strmDocument = strmDocument;
            Syncfusion.Licensing.SyncfusionLicenseProvider.RegisterLicense("NRAiBiAaIQQuGjN/V0Z+XU9EaFtFVmJLYVB3WmpQdldgdVRMZVVbQX9PIiBoS35RdEVlWXZecHRcRmRdVkJ3");
        }
        public ClseAdd_Signatory_Page(string szDBName, string szAppXmlPath, string szFilePath)
        {
            msgError = "";
            _szAppXmlPath = szAppXmlPath;
            _szDBName = szDBName;
            _objDal = new ClsBuildQuery(_szDBName, _szAppXmlPath);
            _objDal.OpenConnection(ConnectionFor.DocsExecutive, ConnectionType.NewConnection);
            _strmDocument = null;
            _szFilePath = szFilePath;
            Syncfusion.Licensing.SyncfusionLicenseProvider.RegisterLicense("NRAiBiAaIQQuGjN/V0Z+XU9EaFtFVmJLYVB3WmpQdldgdVRMZVVbQX9PIiBoS35RdEVlWXZecHRcRmRdVkJ3");
        }


        #region ... Public Functions ....
        public bool Add_Signatory_Page(int iDCR_Number)
        {
            bool bResult = true;
            IDataReader objDataReader = null;
            bool bAutoGenerateSignatoryPage = false;
            List<clsSignatore> lstSignatures = new List<clsSignatore>();

            try
            {
                switch (eDocumentProcess)
                {

                    case Documents_Process.Preview:

                        _szSqlQuery = " select otua_erutangis_etareneg from zespl_setalpmet_cod Doc inner join  zespl_ofni_cod D " +
                            " on d.ynapmoc = doc.ynapmoc and d.noitacol = doc.noitacol and D.tnemtraped = Doc.tnemtraped and D.epyt_cod = doc.epyt_cod" +
                            " where on_frc =" + iDCR_Number + " and  otua_erutangis_etareneg=1 and D.sutats=18";
                        bAutoGenerateSignatoryPage = _objDal.IsRecordExist(_szSqlQuery);
                        if (_objDal.msgError != "")
                            throw new Exception(_objDal.msgError);

                        break;

                    default:
                        _szSqlQuery = " select otua_erutangis_etareneg from zespl_setalpmet_cod Doc inner join  zespl_ofni_cod D " +
                            " on d.ynapmoc = doc.ynapmoc and d.noitacol = doc.noitacol and D.tnemtraped = Doc.tnemtraped and D.epyt_cod = doc.epyt_cod" +
                            " where on_frc =" + iDCR_Number + " and  otua_erutangis_etareneg=1";
                        bAutoGenerateSignatoryPage = _objDal.IsRecordExist(_szSqlQuery);
                        if (_objDal.msgError != "")
                            throw new Exception(_objDal.msgError);
                        break;
                }



                if (bAutoGenerateSignatoryPage)
                {

                    eDocsDN_BaseFunctions.ClsBaseFunctions objDate = new eDocsDN_BaseFunctions.ClsBaseFunctions(_objDal, _szAppXmlPath);
                    _szDateFormat = Get_Date_Format(iDCR_Number);
                    if (_szDateFormat != "")
                        _szDateFormat = objDate.GetCodeDescription(_szDateFormat.ToString(), "DT");
                    else
                        _szDateFormat = objDate.GetCodeDescription("1", "DT");

                    //_szSqlQuery = "select epyt_resu, lvl_qes, d.di_resu, td_sutats, mt_sutats, ot_detageled, codno_tnirp,U.noitangised,U.dc_tped,u.eltit+' '+  u.emanf+' '+u.emanm+' '+u.emanl as FullName " +
                    //            " from zespl_tsid_cod d inner join zespl_tsm_resu U on d.di_resu = U.di_resu where epyt_resu in('R', 'A') And yek_cod =" + iDCR_Number + " and d.codno_tnirp=1  Union " +
                    //            "  select  'AU' as epyt_resu, 0 as lvl_qes,di_rohtua as di_resu ,ISNULL(no_degnahc ,d.no_detaerc) as td_sutats," +
                    //            " ISNULL(ta_degnahc ,d.ta_detaerc) as mt_sutats, null as ot_detageled, 1 as codno_tnirp,U.noitangised,U.dc_tped,u.eltit+' '+  u.emanf+' '+u.emanm+' '+u.emanl as FullName " +
                    //            " from zespl_ofni_cod d inner join zespl_tsm_resu U on d.di_rohtua = U.di_resu where on_frc = " + iDCR_Number + "   order by td_sutats ,mt_sutats";

                    _szSqlQuery = "select epyt_resu, lvl_qes, d.di_resu, td_sutats, mt_sutats, ot_detageled, codno_tnirp,C.csed_dc as noitangised ,Dept.csed_dc as dc_tped ,u.eltit + ' ' + u.emanf + ' ' + u.emanm + ' ' + u.emanl as FullName" +
                                  " from zespl_tsid_cod d inner join zespl_tsm_resu U on d.di_resu = U.di_resu join zespl_tsm_edoc C on C.edoc = U.noitangised " +
                                  " inner join zespl_tsm_edoc Dept on Dept.edoc = U.dc_tped where epyt_resu in('R', 'A') And yek_cod = " + iDCR_Number + " and d.codno_tnirp = 1  Union " +
                                  " select  'AU' as epyt_resu, 0 as lvl_qes,di_rohtua as di_resu ,ISNULL(no_degnahc, d.no_detaerc) as td_sutats, " +
                                 " ISNULL(ta_degnahc, d.ta_detaerc) as mt_sutats, null as ot_detageled, 1 as codno_tnirp,C.csed_dc as noitangised ,Dept.csed_dc as dc_tped,u.eltit + ' ' + u.emanf + ' ' + u.emanm + ' ' + u.emanl as FullName" +
                                 " from zespl_ofni_cod d inner  join zespl_tsm_resu U on d.di_rohtua = U.di_resu join zespl_tsm_edoc C on C.edoc = U.noitangised inner join zespl_tsm_edoc Dept on Dept.edoc = U.dc_tped " +
                                 " where on_frc = " + iDCR_Number + "   order by td_sutats ,mt_sutats ";



                    if (!_objDal.IsRecordExist(_szSqlQuery))
                        throw new Exception("Record Not Exists");

                    objDataReader = _objDal.DecideDatabaseQDR(_szSqlQuery);
                    if (_objDal.msgError != "")
                        throw new Exception(_objDal.msgError);

                    while (objDataReader.Read())
                    {
                        clsSignatore oSignature = new clsSignatore();
                        oSignature.UserID = objDataReader["di_resu"].ToString();
                        oSignature.UserDate = Convert.ToDateTime(objDataReader["td_sutats"]);
                        oSignature.UserTime = Convert.ToDateTime(objDataReader["mt_sutats"]);
                        oSignature.UserDesignation = objDataReader["noitangised"].ToString();
                        oSignature.UserType = objDataReader["epyt_resu"].ToString();
                        oSignature.Sequence = objDataReader["lvl_qes"].ToString();
                        oSignature.UserDepartment = objDataReader["dc_tped"].ToString();
                        oSignature.UserFullName = objDataReader["FullName"].ToString();
                        lstSignatures.Add(oSignature);
                        oSignature = null;
                    }
                    if (objDataReader.Read())
                    {
                        objDataReader.Close();
                        objDataReader.Dispose();
                    }
                    objDataReader = null;

                    if (_strmDocument != null)
                        Add_Signatory_Page_stream(lstSignatures);
                    else
                        Add_Signatory_Page(lstSignatures);
                }
            }
            catch (Exception ex)
            {
                bResult = false;
                msgError = ex.Message;
                ////File.AppendAllText(_szLogFileName, DateTime.Now + " Error :Add_Signatory_Page : " + ex.Message + Environment.NewLine);
                ////File.AppendAllText(_szLogFileName, DateTime.Now + " Error :Add_Signatory_Page : " + ex.StackTrace + Environment.NewLine);
            }
            finally { }
            return bResult;
        }

        public Stream Delete_Signatures(int iDCR_Number)
        {
            bool bResult = true;
            bool bAutoGenerateSignatoryPage = false;
            try
            {
                //_szSqlQuery = " select otua_erutangis_etareneg from zespl_setalpmet_cod Doc inner join  zespl_ofni_cod D " +
                //                " on d.ynapmoc = doc.ynapmoc and d.noitacol = doc.noitacol and D.tnemtraped = Doc.tnemtraped and D.epyt_cod = doc.epyt_cod" +
                //                " where on_frc =" + iDCR_Number + " and  otua_erutangis_etareneg=1";
                //bAutoGenerateSignatoryPage = _objDal.IsRecordExist(_szSqlQuery);
                //if (_objDal.msgError != "")
                //    throw new Exception(_objDal.msgError);

                //if (bAutoGenerateSignatoryPage)
                //{
                ////File.AppendAllText(_szLogFileName, DateTime.Now + " Delete_Signatures " + Environment.NewLine);
                if (_strmDocument != null)
                    _strmDocument = Delete_Signature_Part_Stream();
                else
                    Delete_Signature_Part();
                //}
            }
            catch (Exception ex)
            {
                ////File.AppendAllText(_szLogFileName, DateTime.Now + " Error :Delete_Signatures : " + ex.Message + Environment.NewLine);
                ////File.AppendAllText(_szLogFileName, DateTime.Now + " Error :Delete_Signatures : " + ex.StackTrace + Environment.NewLine);
            }
            finally { }
            return _strmDocument;
        }
        #endregion

        #region .... Private Fuctions ...

        private void Add_Signatory_Page(List<clsSignatore> lstSignatures)
        {
            EntityCollection firstDocumentHeader = null;
            EntityCollection firstDocumentFooter = null;
            try
            {
                Delete_Signature_Part();
                using (WordDocument document = new WordDocument(_szFilePath))
                {
                    #region ..... Add New Section ....
                    IWSection sectionClone = document.Sections[0];
                    if (sectionClone.HeadersFooters.FirstPageHeader != null)
                    {
                        firstDocumentHeader = sectionClone.HeadersFooters.FirstPageHeader.ChildEntities;
                        firstDocumentFooter = sectionClone.HeadersFooters.FirstPageFooter.ChildEntities;
                    }
                    else
                    {
                        firstDocumentHeader = sectionClone.HeadersFooters.Header.ChildEntities;
                        firstDocumentFooter = sectionClone.HeadersFooters.Footer.ChildEntities;
                    }

                    IWSection section = document.AddSection();
                    Syncfusion.DocIO.DLS.BookmarkStart bookmarkStart = new Syncfusion.DocIO.DLS.BookmarkStart(document, "custompage");
                    Syncfusion.DocIO.DLS.BookmarkEnd bookmarkEnd = new Syncfusion.DocIO.DLS.BookmarkEnd(document, "custompage");
                    section.AddParagraph().Items.Add(bookmarkStart);
                    section.AddParagraph().Items.Add(bookmarkEnd);
                    foreach (Entity entity in firstDocumentHeader)
                    {
                        section.HeadersFooters.Header.ChildEntities.Add(entity.Clone());
                    }

                    foreach (Entity entity in firstDocumentFooter)
                    {
                        section.HeadersFooters.Footer.ChildEntities.Add(entity.Clone());
                    }
                    document.Sections.Insert(0, section);
                    section.AddParagraph().Items.Add(bookmarkStart);
                    section.AddParagraph().Items.Add(bookmarkEnd);

                    #endregion

                    #region ..... Create a Signatory Page .....
                    //..Add a paragraph to the section.

                    IWTextRange textRange = section.AddParagraph().AppendText("Signatory Table");
                    IWParagraph paragraph = section.Paragraphs[0];
                    paragraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                    textRange.OwnerParagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                    textRange.CharacterFormat.FontName = "Times New Roman";
                    textRange.CharacterFormat.FontSize = 12;
                    textRange.CharacterFormat.Bold = true;
                    section.AddParagraph();

                    //Adds a new table into Word document
                    IWTable table = section.AddTable();
                    WTable table1 = section.Tables[0] as WTable;
                    //Specifies the total number of rows & columns
                    table.ResetCells(lstSignatures.Count + 1, 4);
                    table.TableFormat.HorizontalAlignment = RowAlignment.Center;
                    table1.AutoFit(AutoFitType.FitToWindow);


                    #region ... table  Header ....
                    textRange = table[0, 0].AddParagraph().AppendText("Signatories");
                    IWParagraph tparagraph = table[0, 0].Paragraphs[0];
                    tparagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                    table[0, 0].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
                    textRange.CharacterFormat.FontName = "Times New Roman";
                    textRange.CharacterFormat.Bold = true;
                    textRange.CharacterFormat.FontSize = 11;

                    textRange = table[0, 1].AddParagraph().AppendText("Name (Department)");
                    tparagraph = table[0, 1].Paragraphs[0];
                    tparagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                    textRange.CharacterFormat.FontName = "Times New Roman";
                    textRange.CharacterFormat.Bold = true;
                    textRange.CharacterFormat.FontSize = 11;

                    textRange = table[0, 2].AddParagraph().AppendText("Designation");
                    tparagraph = table[0, 2].Paragraphs[0];
                    tparagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                    textRange.CharacterFormat.FontName = "Times New Roman";
                    textRange.CharacterFormat.Bold = true;
                    textRange.CharacterFormat.FontSize = 11;

                    textRange = table[0, 3].AddParagraph().AppendText("Date Time");
                    tparagraph = table[0, 3].Paragraphs[0];
                    tparagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                    textRange.CharacterFormat.FontName = "Times New Roman";
                    textRange.CharacterFormat.Bold = true;
                    textRange.CharacterFormat.FontSize = 11;

                    #endregion


                    #region ..... Add Author ....
                    clsSignatore oAuthor = lstSignatures.Find(o => o.UserType == "AU");

                    textRange = table[1, 0].AddParagraph().AppendText("Prepared By");
                    tparagraph = table[1, 0].Paragraphs[0];
                    tparagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                    textRange.CharacterFormat.FontName = "Times New Roman";
                    textRange.CharacterFormat.Bold = true;
                    textRange.CharacterFormat.FontSize = 11;

                    textRange = table[1, 1].AddParagraph().AppendText(oAuthor.UserFullName);
                    tparagraph = table[1, 1].Paragraphs[0];
                    tparagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                    textRange.CharacterFormat.FontName = "Times New Roman";
                    textRange.CharacterFormat.FontSize = 11;


                    textRange = table[1, 1].AddParagraph().AppendText("(" + oAuthor.UserDepartment + ")");
                    tparagraph = table[1, 1].Paragraphs[1];
                    tparagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                    textRange.CharacterFormat.FontName = "Times New Roman";
                    textRange.CharacterFormat.FontSize = 11;


                    textRange = table[1, 2].AddParagraph().AppendText(oAuthor.UserDesignation);
                    tparagraph = table[1, 2].Paragraphs[0];
                    tparagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                    textRange.CharacterFormat.FontName = "Times New Roman";
                    textRange.CharacterFormat.FontSize = 11;



                    textRange = table[1, 3].AddParagraph().AppendText(oAuthor.UserDate.ToString(_szDateFormat) + " " + oAuthor.UserTime.ToString("T"));
                    tparagraph = table[1, 3].Paragraphs[0];
                    tparagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                    textRange.CharacterFormat.FontName = "Times New Roman";
                    textRange.CharacterFormat.FontSize = 11;

                    #endregion

                    List<clsSignatore> oReviewr = lstSignatures.FindAll(o => o.UserType != "AU");

                    for (int i = 0; i < oReviewr.Count; i++)
                    {
                        int iTableRow = i + 2;
                        if (oReviewr[i].UserType == "R")
                            textRange = table[iTableRow, 0].AddParagraph().AppendText("Reviewed By");
                        else
                            textRange = table[iTableRow, 0].AddParagraph().AppendText("Approved By");

                        tparagraph = table[iTableRow, 0].Paragraphs[0];
                        tparagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                        textRange.CharacterFormat.FontName = "Times New Roman";
                        textRange.CharacterFormat.Bold = true;
                        textRange.CharacterFormat.FontSize = 11;

                        textRange = table[iTableRow, 1].AddParagraph().AppendText(oReviewr[i].UserFullName);
                        tparagraph = table[iTableRow, 1].Paragraphs[0];
                        tparagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                        textRange.CharacterFormat.FontName = "Times New Roman";
                        textRange.CharacterFormat.FontSize = 11;


                        textRange = table[iTableRow, 1].AddParagraph().AppendText("(" + oAuthor.UserDepartment + ")");
                        tparagraph = table[iTableRow, 1].Paragraphs[1];
                        tparagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                        textRange.CharacterFormat.FontName = "Times New Roman";
                        textRange.CharacterFormat.FontSize = 11;

                        textRange = table[iTableRow, 2].AddParagraph().AppendText(oReviewr[i].UserDesignation);
                        tparagraph = table[iTableRow, 2].Paragraphs[0];
                        tparagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                        textRange.CharacterFormat.FontName = "Times New Roman";
                        textRange.CharacterFormat.FontSize = 11;

                        textRange = table[iTableRow, 3].AddParagraph().AppendText(oReviewr[i].UserDate.ToString(_szDateFormat) + " " + oReviewr[i].UserTime.ToString("T"));
                        tparagraph = table[iTableRow, 3].Paragraphs[0];
                        tparagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                        textRange.CharacterFormat.FontName = "Times New Roman";
                        textRange.CharacterFormat.FontSize = 11;

                    }
                    #endregion
                    ////File.AppendAllText(_szLogFileName, DateTime.Now + " outputFileStream : " + Environment.NewLine);
                    using (FileStream outputFileStream = new FileStream(_szFilePath, FileMode.OpenOrCreate, FileAccess.Write))
                    {
                        ////File.AppendAllText(_szLogFileName, DateTime.Now + " Save : " + Environment.NewLine);
                        document.Save(outputFileStream, FormatType.Docx);
                    }
                }
            }
            finally { }
        }

        private void Add_Signatory_Page_stream(List<clsSignatore> lstSignatures)
        {
            EntityCollection firstDocumentHeader = null;
            EntityCollection firstDocumentFooter = null;
            try
            {
                Delete_Signature_Part_Stream();
                ////File.AppendAllText(_szLogFileName, DateTime.Now + " Add_Signatory_Page_stream : " + Environment.NewLine);
                using (WordDocument document = new WordDocument(_strmDocument, FormatType.Docx))
                {
                    //..//File.AppendAllText(_szLogFileName, DateTime.Now + " document : " + Environment.NewLine);
                    #region ..... Add New Section ....
                    ////File.AppendAllText(_szLogFileName, DateTime.Now + " IWSection sectionClone = document.Sections[0]; : " + Environment.NewLine);
                    IWSection sectionClone = document.Sections[0];
                    if (sectionClone.HeadersFooters.FirstPageHeader != null)
                    {
                        firstDocumentHeader = sectionClone.HeadersFooters.FirstPageHeader.ChildEntities;
                        firstDocumentFooter = sectionClone.HeadersFooters.FirstPageFooter.ChildEntities;
                    }
                    else
                    {
                        firstDocumentHeader = sectionClone.HeadersFooters.Header.ChildEntities;
                        firstDocumentFooter = sectionClone.HeadersFooters.Footer.ChildEntities;
                    }

                    ////File.AppendAllText(_szLogFileName, DateTime.Now + "before document.AddSection(); : " + Environment.NewLine);
                    IWSection section = document.AddSection();
                    //File.AppendAllText(_szLogFileName, DateTime.Now + "After document.AddSection(); : " + Environment.NewLine);

                    //File.AppendAllText(_szLogFileName, DateTime.Now + "before Bookmark: " + Environment.NewLine);
                    Syncfusion.DocIO.DLS.BookmarkStart bookmarkStart = new Syncfusion.DocIO.DLS.BookmarkStart(document, "custompage");
                    Syncfusion.DocIO.DLS.BookmarkEnd bookmarkEnd = new Syncfusion.DocIO.DLS.BookmarkEnd(document, "custompage");
                    //File.AppendAllText(_szLogFileName, DateTime.Now + "After Bookmark: " + Environment.NewLine);
                    section.AddParagraph().Items.Add(bookmarkStart);
                    section.AddParagraph().Items.Add(bookmarkEnd);
                    //File.AppendAllText(_szLogFileName, DateTime.Now + "section.AddParagraph().Items.Add(bookmarkEnd);: " + Environment.NewLine);

                    foreach (Entity entity in firstDocumentHeader)
                    {
                        //File.AppendAllText(_szLogFileName, DateTime.Now + "section.HeadersFooters.Header.ChildEntities.Add(entity.Clone());" + Environment.NewLine);
                        section.HeadersFooters.Header.ChildEntities.Add(entity.Clone());
                    }

                    foreach (Entity entity in firstDocumentFooter)
                    {
                        //File.AppendAllText(_szLogFileName, DateTime.Now + "section.HeadersFooters.Footer.ChildEntities.Add(entity.Clone());" + Environment.NewLine);
                        section.HeadersFooters.Footer.ChildEntities.Add(entity.Clone());
                    }
                    //File.AppendAllText(_szLogFileName, DateTime.Now + "before document.Sections.Insert(0, section);" + Environment.NewLine);
                    document.Sections.Insert(0, section);
                    //File.AppendAllText(_szLogFileName, DateTime.Now + "document.Sections.Insert(0, section);" + Environment.NewLine);
                    //File.AppendAllText(_szLogFileName, DateTime.Now + "before section.AddParagraph().Items.Add(bookmarkStart);" + Environment.NewLine);
                    section.AddParagraph().Items.Add(bookmarkStart);
                    section.AddParagraph().Items.Add(bookmarkEnd);
                    //File.AppendAllText(_szLogFileName, DateTime.Now + "After section.AddParagraph().Items.Add(bookmarkStart);" + Environment.NewLine);
                    #endregion

                    #region ..... Create a Signatory Page .....
                    //..Add a paragraph to the section.

                    IWTextRange textRange = section.AddParagraph().AppendText("Signatory Table");
                    IWParagraph paragraph = section.Paragraphs[0];
                    paragraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                    textRange.OwnerParagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                    textRange.CharacterFormat.FontName = "Times New Roman";
                    textRange.CharacterFormat.FontSize = 12;
                    textRange.CharacterFormat.Bold = true;
                    section.AddParagraph();
                    //File.AppendAllText(_szLogFileName, DateTime.Now + "section.AddParagraph();" + Environment.NewLine);

                    //Adds a new table into Word document
                    IWTable table = section.AddTable();
                    WTable table1 = section.Tables[0] as WTable;
                    //Specifies the total number of rows & columns
                    table.ResetCells(lstSignatures.Count + 1, 4);
                    table.TableFormat.HorizontalAlignment = RowAlignment.Center;
                    table1.AutoFit(AutoFitType.FitToWindow);
                    //File.AppendAllText(_szLogFileName, DateTime.Now + "table1.AutoFit(AutoFitType.FitToWindow);" + Environment.NewLine);


                    #region ... table  Header ....

                    //File.AppendAllText(_szLogFileName, DateTime.Now + "textRange = table[0, 0].AddParagraph().AppendText(Signatory);" + Environment.NewLine);
                    textRange = table[0, 0].AddParagraph().AppendText("Signatories");

                    IWParagraph tparagraph = table[0, 0].Paragraphs[0];
                    tparagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                    table[0, 0].CellFormat.VerticalAlignment = VerticalAlignment.Middle;
                    textRange.CharacterFormat.FontName = "Times New Roman";
                    textRange.CharacterFormat.Bold = true;
                    textRange.CharacterFormat.FontSize = 11;

                    textRange = table[0, 1].AddParagraph().AppendText("Name (Department)");
                    tparagraph = table[0, 1].Paragraphs[0];
                    tparagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                    textRange.CharacterFormat.FontName = "Times New Roman";
                    textRange.CharacterFormat.Bold = true;
                    textRange.CharacterFormat.FontSize = 11;

                    textRange = table[0, 2].AddParagraph().AppendText("Designation");
                    tparagraph = table[0, 2].Paragraphs[0];
                    tparagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                    textRange.CharacterFormat.FontName = "Times New Roman";
                    textRange.CharacterFormat.Bold = true;
                    textRange.CharacterFormat.FontSize = 11;

                    textRange = table[0, 3].AddParagraph().AppendText("Date Time");
                    tparagraph = table[0, 3].Paragraphs[0];
                    tparagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                    textRange.CharacterFormat.FontName = "Times New Roman";
                    textRange.CharacterFormat.Bold = true;
                    textRange.CharacterFormat.FontSize = 11;

                    #endregion


                    #region ..... Add Author ....
                    //File.AppendAllText(_szLogFileName, DateTime.Now + "clsSignatore oAuthor = lstSignatures.Find(o => o.UserType == AU);" + Environment.NewLine);
                    clsSignatore oAuthor = lstSignatures.Find(o => o.UserType == "AU");

                    textRange = table[1, 0].AddParagraph().AppendText("Prepared By");
                    tparagraph = table[1, 0].Paragraphs[0];
                    tparagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                    textRange.CharacterFormat.FontName = "Times New Roman";
                    textRange.CharacterFormat.Bold = true;
                    textRange.CharacterFormat.FontSize = 11;

                    textRange = table[1, 1].AddParagraph().AppendText(oAuthor.UserFullName);
                    tparagraph = table[1, 1].Paragraphs[0];
                    tparagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                    textRange.CharacterFormat.FontName = "Times New Roman";
                    textRange.CharacterFormat.FontSize = 11;


                    textRange = table[1, 1].AddParagraph().AppendText("(" + oAuthor.UserDepartment + ")");
                    tparagraph = table[1, 1].Paragraphs[1];
                    tparagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                    textRange.CharacterFormat.FontName = "Times New Roman";
                    textRange.CharacterFormat.FontSize = 11;


                    textRange = table[1, 2].AddParagraph().AppendText(oAuthor.UserDesignation);
                    tparagraph = table[1, 2].Paragraphs[0];
                    tparagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                    textRange.CharacterFormat.FontName = "Times New Roman";
                    textRange.CharacterFormat.FontSize = 11;



                    textRange = table[1, 3].AddParagraph().AppendText(oAuthor.UserDate.ToString(_szDateFormat) + " " + oAuthor.UserTime.ToString("T"));
                    tparagraph = table[1, 3].Paragraphs[0];
                    tparagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                    textRange.CharacterFormat.FontName = "Times New Roman";
                    textRange.CharacterFormat.FontSize = 11;

                    //File.AppendAllText(_szLogFileName, DateTime.Now + "Author" + Environment.NewLine);

                    #endregion

                    List<clsSignatore> oReviewr = lstSignatures.FindAll(o => o.UserType != "AU");

                    for (int i = 0; i < oReviewr.Count; i++)
                    {
                        int iTableRow = i + 2;
                        if (oReviewr[i].UserType == "R")
                            textRange = table[iTableRow, 0].AddParagraph().AppendText("Reviewed By");
                        else
                            textRange = table[iTableRow, 0].AddParagraph().AppendText("Approved By");

                        tparagraph = table[iTableRow, 0].Paragraphs[0];
                        tparagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                        textRange.CharacterFormat.FontName = "Times New Roman";
                        textRange.CharacterFormat.Bold = true;
                        textRange.CharacterFormat.FontSize = 11;

                        textRange = table[iTableRow, 1].AddParagraph().AppendText(oReviewr[i].UserFullName);
                        tparagraph = table[iTableRow, 1].Paragraphs[0];
                        tparagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                        textRange.CharacterFormat.FontName = "Times New Roman";
                        textRange.CharacterFormat.FontSize = 11;


                        textRange = table[iTableRow, 1].AddParagraph().AppendText("(" + oReviewr[i].UserDepartment + ")");
                        tparagraph = table[iTableRow, 1].Paragraphs[1];
                        tparagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                        textRange.CharacterFormat.FontName = "Times New Roman";
                        textRange.CharacterFormat.FontSize = 11;

                        textRange = table[iTableRow, 2].AddParagraph().AppendText(oReviewr[i].UserDesignation);
                        tparagraph = table[iTableRow, 2].Paragraphs[0];
                        tparagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                        textRange.CharacterFormat.FontName = "Times New Roman";
                        textRange.CharacterFormat.FontSize = 11;

                        textRange = table[iTableRow, 3].AddParagraph().AppendText(oReviewr[i].UserDate.ToString(_szDateFormat) + " " + oReviewr[i].UserTime.ToString("T"));
                        tparagraph = table[iTableRow, 3].Paragraphs[0];
                        tparagraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
                        textRange.CharacterFormat.FontName = "Times New Roman";
                        textRange.CharacterFormat.FontSize = 11;

                    }
                    #endregion
                    //File.AppendAllText(_szLogFileName, DateTime.Now + " document.Save : " + Environment.NewLine);
                    document.Save(_strmDocument, FormatType.Docx);
                }
            }
            finally { }
        }

        private Stream Delete_Signature_Part_Stream()
        {
            try
            {
                //File.AppendAllText(_szLogFileName, DateTime.Now + " Delete_Signature_Part_Stream " + Environment.NewLine);
                using (WordDocument document = new WordDocument(_strmDocument, FormatType.Automatic))
                {
                    // Get the bookmark instance by using FindByName method of BookmarkCollection with bookmark name
                    Syncfusion.DocIO.DLS.Bookmark bookmark = document.Bookmarks.FindByName("custompage");
                    if (bookmark != null)
                    {
                        // Get the owner section of bookmark.
                        //File.AppendAllText(_szLogFileName, DateTime.Now + " bookmark != null " + Environment.NewLine);
                        WSection section = GetOwnerEntity(bookmark.BookmarkStart) as WSection;
                        if (section != null)
                        {
                            // Get the index value of section.
                            int sectionIndex = document.ChildEntities.IndexOf(section);
                            int sectionNumber = sectionIndex + 1;
                            document.Sections.RemoveAt(sectionIndex);
                        }
                        document.Save(_strmDocument, FormatType.Docx);
                    }

                }

            }
            finally { }
            return _strmDocument;
        }

        private void Delete_Signature_Part()
        {
            try
            {
                using (FileStream fileStreamPath = new FileStream(Path.GetFullPath(_szFilePath), FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    //Open an existing Word document.
                    using (WordDocument document = new WordDocument(fileStreamPath, FormatType.Automatic))
                    {
                        // Get the bookmark instance by using FindByName method of BookmarkCollection with bookmark name
                        Syncfusion.DocIO.DLS.Bookmark bookmark = document.Bookmarks.FindByName("custompage");
                        if (bookmark != null)
                        {
                            // Get the owner section of bookmark.
                            WSection section = GetOwnerEntity(bookmark.BookmarkStart) as WSection;
                            if (section != null)
                            {
                                // Get the index value of section.
                                int sectionIndex = document.ChildEntities.IndexOf(section);
                                int sectionNumber = sectionIndex + 1;
                                document.Sections.RemoveAt(sectionIndex);
                            }
                            document.Save(_szFilePath);
                        }
                    }
                }
            }
            catch (Exception)
            {
            }
        }

        private string Get_Date_Format(int iDCR_Number)
        {
            string szConfigDate = string.Empty;
            object _objReturnVal = null;
            try
            {
                _szSqlQuery = " SELECT dt_ngis_ele FROM zespl_setalpmet_cod doc inner join zespl_ofni_cod d on doc.ynapmoc=d.ynapmoc and " +
                              " doc.noitacol = d.noitacol and doc.tnemtraped = d.tnemtraped and doc.epyt_cod = d.epyt_cod" +
                              "  WHERE d.on_frc =" + iDCR_Number;

                _objReturnVal = _objDal.GetFirstColumnValue(_szSqlQuery);
                if (_objDal.msgError != "")
                    throw new Exception(_objDal.msgError);

                if (_objReturnVal != null)
                {
                    szConfigDate = Convert.ToString(_objReturnVal);
                }
                _objReturnVal = null;
            }

            finally { }
            return szConfigDate;
        }

        private static Entity GetOwnerEntity(Syncfusion.DocIO.DLS.BookmarkStart bookmarkStart)
        {
            Entity baseEntity = bookmarkStart.Owner;

            while (!(baseEntity is WSection))
            {
                if (baseEntity is null)
                    return baseEntity;
                baseEntity = baseEntity.Owner;
            }
            return baseEntity;
        }

        #endregion

        #region .... IDISPOSABLE ....

        public void Dispose()
        {
            Dispose(true);
        }
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
            }
            else
            {

            }
        }

        ~ClseAdd_Signatory_Page()
        {
            Dispose(false);
        }


        #endregion


    }
}
